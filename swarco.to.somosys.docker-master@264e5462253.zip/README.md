**Installation on VM:**  
1. Get the encryption key.
2. Get the ssh keys for the somosys user.
3. run: 
`CONFIG_ENV=prod docker-compose up -d` 

**Config use cases:**  
The config directory contains two files:
1. config.yml: Encrypted file using ansible-vault, In order to read the config you will need the vault password
2. config.yml.encrypted: An encrypted file from the plain-text config.yml, this file is used only by the application  
 in order to read the configs using a decryption key stored on the VM.

**Read the config.yml:**  
In order to read the config.yml you need only the vault password.  

**Update the config:**  
We need to install once this package:
`pip install pycrypto==2.6.1`  
In order to update the config you need the vault password and the encryption key.  
a. Decrypt the config.yml using ansible-vault.  
b. Update your configs.  
c. Generate a new config.yml.encrypted file using:  
`pyhton src/utils/encryption_tool.py -k {path to the encryption key}`  
****d. Encrypt the config.yml again with the ansible-vault.****  
