import time
import logging
import datetime

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.executors.pool import ThreadPoolExecutor, ProcessPoolExecutor

from src.utils.twilio_connector import TwilioConnector

logger = logging.getLogger(__name__)
CHECKER_WINDOW = 10


class Job:
    def __init__(self, period_in_minutes, checker_obj, reschedule_in_sec=60):
        self.period = period_in_minutes
        self.reschedule_in_sec = reschedule_in_sec
        self.checker_obj = checker_obj
        self.id_ = getattr(self.checker_obj, "url", None) or getattr(self.checker_obj, "hostname", None)
        self.call_timeout = self.period
        self.last_call_at = None

    def set_call_timeout(self, timeout):
        self.call_timeout = timeout


class Checker:
    jobs = []
    scheduler = None

    @classmethod
    def subscribe(cls, job):
        if not isinstance(job, Job):
            raise TypeError("job must be of type Job")
        cls.jobs.append(job)

    @classmethod
    def get_job_by_id(cls, id_):
        for job in cls.jobs:
            if job.id_ == id_:
                return job
        return None

    @classmethod
    def handle_report(cls):
        """Get failed jobs in a predefined window (CHECKER_WINDOW), and decide if needs call"""
        while True:
            failed_jobs = cls.get_failed_jobs()
            if failed_jobs:
                try:
                    cls.decide_call(failed_jobs)
                except Exception as e:
                    logger.error(f"Exception in handle_report {str(e)}")
            time.sleep(CHECKER_WINDOW)

    @classmethod
    def decide_call(cls, failed_jobs):
        try:
            first_time = [job for job in failed_jobs if job.last_call_at is None]
            have_last_call = [job for job in failed_jobs if job.last_call_at is not None]
            if first_time:
                cls.handle_call(first_time)
            if have_last_call:
                cls.handle_call(have_last_call)
        except Exception as e:
            raise e

    @classmethod
    def handle_call(cls, failed_jobs):
        report = ''
        must_call = []
        for job in failed_jobs:
            if job.last_call_at:
                if (datetime.datetime.now() - job.last_call_at).total_seconds()/60 >= job.call_timeout:
                    must_call.append(job)
                    report += "{}. ".format(job.checker_obj.report.get_msg())
            else:
                must_call.append(job)
                report += "{}. ".format(job.checker_obj.report.get_msg())

        if report:
            for j in must_call:
                j.checker_obj.report.set_called(called=True)
                j.last_call_at = datetime.datetime.now()
                j.call_timeout = j.period
            TwilioConnector.make_call(report=report)

    @classmethod
    def get_failed_jobs(cls):
        """Get failed jobs
        :return list of Job"""

        failed = []
        for job in cls.jobs:
            if not job.checker_obj.report.get_status() and not job.checker_obj.report.get_called():
                failed.append(job)
        return failed

    @classmethod
    def update_call_timeout(cls, job_id, timeout):
        for job in cls.jobs:
            if job.id_ == job_id:
                job.set_call_timeout(timeout)
                return True
        return False

    @classmethod
    def run(cls):
        executors = {
            'default': ThreadPoolExecutor(20),
            'processpool': ProcessPoolExecutor(7)
        }
        job_defaults = {
            'coalesce': False,
            'max_instances': 7
        }
        cls.scheduler = BackgroundScheduler(executors=executors, job_defaults=job_defaults)

        for job in cls.jobs:
            cls.scheduler.add_job(job.checker_obj.task, 'interval', minutes=job.period, id=job.id_)
        cls.scheduler.start()

    @classmethod
    def reschedule_job(cls, url):
        """Reschedule jobs, currently used only in Webcheckers to optimise SLA calculations"""
        job = cls.scheduler.get_job(job_id=url)
        j = cls.get_job_by_id(url)
        if j:
            job.modify(next_run_time=datetime.datetime.now() + datetime.timedelta(seconds=j.reschedule_in_sec))
        else:
            logger.error("Job not found with id: {}".format(url))
