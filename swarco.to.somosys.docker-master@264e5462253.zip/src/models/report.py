from datetime import datetime
from src.db_helper import db
import logging
logger = logging.getLogger(__name__)


class Report(db.Document):

    status_code = db.IntField(required=True)
    reason = db.StringField(required=True)
    created = db.DateTimeField(required=True, default=datetime.utcnow)
    type_ = db.StringField(required=True, default="uptime")
    value = db.StringField(required=True, default="up")
    source = db.StringField(required=True)
    v_ = db.StringField(required=True, default="v1")

    meta = {'indexes': [
        'created',
        ('source', 'created')
    ]}

    def __init__(self, msg='', *args, **kwargs):
        super(Report, self).__init__(*args, **kwargs)
        self.status = True
        self.called = False
        self.msg = msg

    def update(self, msg, status_code=0, reason=''):
        self.status_code = status_code
        self.reason = reason
        self.msg = msg
        self.status = False
        self.called = False

    def get_status(self):
        return self.status

    def get_called(self):
        return self.called

    def set_called(self, called):
        self.called = called

    def get_msg(self):
        return self.msg

    def json_to_export(self):
        return {'_id': self.id, 'status_code': self.status_code, 'reason': self.reason,
                'created': self.created, 'value': self.value, 'source': self.source, 'v_': self.v_}
