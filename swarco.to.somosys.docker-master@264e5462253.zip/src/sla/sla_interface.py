from datetime import timedelta
import logging

logger = logging.getLogger(__name__)


class Sla:

    @classmethod
    def get_interval(cls, res, d=None):
        sep = None
        d = d or {}
        if all(el.get('value') != 'up' for el in res):
            return d
        for i, el in enumerate(res):
            if el.get('value') == 'up':
                d.update({el.get('created'): (res[:i+1], res[i+1:])})
                sep = i
                break
        res = res[sep+1:]
        return cls.get_interval(res, d)

    @staticmethod
    def calculate_sla(interval_list):
        if isinstance(interval_list, list) and len(interval_list) < 2:
            return timedelta(0)
        down_time = interval_list[-1].get('created') - interval_list[0].get('created')
        return down_time

    @classmethod
    def main(cls, res, reference_period_in_minutes):
        intervals = list(cls.get_interval(res=res).items())
        down_time = timedelta(0)
        if len(intervals) == 0:
            return None, None

        if len(intervals) > 1:
            for el in intervals[:-1]:
                print(type(el))
                interval, _ = el[1]
                down_time += cls.calculate_sla(interval)

        # last interval tuple must be taken both
        interval, rest = intervals[-1][1]
        down_time += cls.calculate_sla(interval) + cls.calculate_sla(rest)

        sla_down = ((down_time.total_seconds() / 60) / reference_period_in_minutes) * 100
        sla_up = 100 - round(sla_down, 4)
        return sla_up, down_time.total_seconds()
