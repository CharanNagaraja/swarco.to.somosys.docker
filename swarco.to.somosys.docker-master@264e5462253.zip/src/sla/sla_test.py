import datetime
from unittest import TestCase
from .sla_interface import Sla


class SlaTest(TestCase):

    def setUp(self) -> None:
        pass

    def tearDown(self) -> None:
        pass

    def test_main(self):
        res = [
            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 28, 39, 752464)},
            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 28, 41, 752464)},
            {'value': 'up', 'created': datetime.datetime(2020, 5, 10, 0, 28, 44, 752464)},

            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 28, 47, 752464)},
            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 28, 50, 752464)},
            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 28, 53, 752464)},
            {'value': 'up', 'created': datetime.datetime(2020, 5, 10, 0, 28, 56, 752464)},

            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 28, 59, 752464)},
            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 29, 2, 752464)},
            {'value': 'up', 'created': datetime.datetime(2020, 5, 10, 0, 29, 5, 752464)},

            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 29, 8, 752464)},
            {'value': 'down', 'created': datetime.datetime(2020, 5, 10, 0, 29, 11, 752464)}
        ]
        uptime_percent, down_time_seconds = Sla.main(res, reference_period_in_minutes=44640) # 44640 min = nb min in May
        self.assertEqual(uptime_percent, 99.9991)
        self.assertEqual(down_time_seconds, 23)
