import MySQLdb
import logging

from src.infra_checks.infra_checker import InfraChecker
from src.models.report import Report
from src.utils import ConfigHandler

logger = logging.getLogger(__name__)


class MySQLChecker(InfraChecker):

    def __init__(self, hostname, username, DBs_to_check, cmd, parent_section_name, port=22, password=None, use_sudo=False, max_repeat=0):
        super().__init__(hostname, username, cmd=cmd, port=port, password=password, max_repeat=max_repeat)
        self.use_sudo = use_sudo
        self.DBs_to_check = DBs_to_check
        self.parent_section_name = parent_section_name
        self.report = Report(msg="DBs {} of MySQL DB of {} have more than 0 rows".format(
            self.DBs_to_check, self.hostname), source=self.hostname)

    def run_command(self):

        output_list = []
        db = None
        for DB in self.DBs_to_check:
            table_output_list = []
            try:
                db = MySQLdb.connect(host=self.hostname, user=self._username, db=DB['name'], port=3306,
                                     passwd=ConfigHandler.get_value('toolchain', 'infra', self.parent_section_name, 'mysql_password'))

                cursor = db.cursor()
                for table in DB["tables_to_check"]:
                    cursor.execute(self._cmd.format(table))
                    result = cursor.fetchall()
                    table_output_list.append((table, result[0][0]))

                output_list.append((DB["name"], table_output_list))
            except Exception as e:
                logger.error(f"Exception in MySQL connection: {e}")
            finally:
                if db:
                    db.close()

        return output_list

    def evaluate_command_output(self, output_list):
        eval_output = []
        for DB, table_output_list in output_list:
            table_outputs = []
            for table, number_of_rows in table_output_list:
                table_outputs.append(f"{table}: {number_of_rows} rows |")
                if int(number_of_rows) == 0:
                    self.report.update(msg="Table {} of DB {} of server {} has 0 rows".format(
                        table, DB, self.hostname))
            eval_output.append(f"{DB} -> " + " ".join(table_outputs))
        self.log_status(eval_output)

    def log_status(self, eval_output):
        for line in eval_output:
            logger.debug(f"{self.hostname}: {line}")
