from paramiko import SSHClient, AutoAddPolicy

import logging

from src.models.report import Report

logger = logging.getLogger(__name__)


class InfraChecker:

    def __init__(self, hostname, username, cmd, port=22, password=None, max_repeat=0):
        self.hostname = hostname
        self.port = port
        self._username = username
        self._password = password
        self._cmd = self.get_cmd(cmd)
        self.max_repeat = max_repeat
        self.report = Report(msg="{} is OK".format(self.hostname), source=self.hostname)

    def get_client(self):
        client = None
        try:
            client = SSHClient()
            client.load_system_host_keys()
            client.set_missing_host_key_policy(AutoAddPolicy())
            client.connect(self.hostname, port=self.port, username=self._username, password=self._password, timeout=60,
                           auth_timeout=60)
            return client
        except Exception as e:
            logger.error(f"Exception in get_client ssh {str(e)}")
            if client:
                client.close()
            raise e

    def get_cmd(self, cmd):
        if cmd and isinstance(cmd, str):
            return cmd
        raise NotImplementedError

    def run_command(self):
        client = None
        try:
            client = self.get_client()
            stdin, stdout, stderr = client.exec_command(self._cmd)
            out = stdout.readlines()
            err = stderr.readlines()
            if err:
                logger.error(err)
                logger.error(out)
                return None
            return out
        except Exception as e:
            logger.error(f"Exception in run_command: {str(e)}")
            raise e
        finally:
            if client:
                client.close()

    def evaluate_command_output(self, command_output):
        raise NotImplementedError

    def log_status(self, eval_output):
        logger.debug(f"{self.hostname}: {eval_output}")

    def main_check(self):
        i = 0
        failed = False
        command_output = None

        if self.max_repeat > 0:
            while i < self.max_repeat:
                try:
                    command_output = self.run_command()
                    failed = False
                    break
                except Exception as e:
                    logger.error(f"Exception in main_check: {e}")
                    failed = True
                i += 1
            if failed:
                self.report.update(msg="{} is unreachable. Exception in establishing SSH connection".format(
                        self.hostname))
                return
        else:
            try:
                command_output = self.run_command()
            except Exception as e:
                logger.error(f"Exception in main_check: {e}")
                self.report.update(msg="{} is unreachable. Exception in establishing SSH connection"
                        .format(self.hostname))
                return

        if not command_output:
            logger.error("command_output is not defined: {}".format(command_output))
            return

        self.evaluate_command_output(command_output)

    def task(self):
        self.main_check()
