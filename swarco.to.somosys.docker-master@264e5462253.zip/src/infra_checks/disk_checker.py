from src.infra_checks.infra_checker import InfraChecker
from src.models.report import Report
import logging

logger = logging.getLogger(__name__)


class DiskChecker(InfraChecker):

    def __init__(self, hostname, username, cmd, port=22, password=None, threshold=90, max_repeat=0):
        super().__init__(hostname, username, cmd=cmd, port=port, password=password, max_repeat=max_repeat)
        self.threshold = threshold
        self.report = Report(msg="disk space of {} is not too full".format(self.hostname), source=self.hostname)

    def evaluate_command_output(self, command_output):
        # TODO: remove debug
        logger.debug(command_output)
        logger.debug(type(command_output))
        disk_space_percentage = command_output[0].strip().replace("%", "")
        if int(disk_space_percentage) > self.threshold:
            self.report.update(msg="disk space of {} is over threshold: {} of {}"
                               .format(self.hostname, disk_space_percentage, self.threshold))
        self.log_status(disk_space_percentage.strip() + "%/" + str(self.threshold) + "%")
