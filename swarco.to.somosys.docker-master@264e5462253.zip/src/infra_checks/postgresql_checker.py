import psycopg2
import logging

from src.infra_checks.infra_checker import InfraChecker
from src.models.report import Report
from src.utils import ConfigHandler

logger = logging.getLogger(__name__)


class PostgreSQLChecker(InfraChecker):

    def __init__(self, hostname, db_username, tables_to_check, cmd, database, parent_section_name, max_repeat=0,
                 password=None):
        super().__init__(hostname, username=None, password=password, cmd=cmd, max_repeat=max_repeat)
        self.tables_to_check = tables_to_check
        self.database = database
        self.parent_section_name = parent_section_name
        self.db_username = db_username
        self.report = Report(msg="Tables {} of PostgreSQL DB of {} have more than 0 rows".format(
            self.tables_to_check, self.hostname), source=self.hostname)

    def run_command(self):
        result_dict = {}
        cursor = None
        connection = None
        try:
            connection = psycopg2.connect(dbname=self.database, user=self.db_username, host=self.hostname, port=5432,
                                          password=ConfigHandler.get_value('toolchain', 'infra',
                                                                           self.parent_section_name, 'password'))

            cursor = connection.cursor()
            for table in self.tables_to_check:
                cursor.execute(self._cmd.format(table))
                query_results = cursor.fetchall()
                if query_results and query_results[0] and query_results[0][0]:
                    result_dict[table] = query_results[0][0]
        except Exception as e:
            logger.error(f"Exception in PostgreSQL handling: {str(e)}")
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()
        return result_dict

    def evaluate_command_output(self, result_dict):
        if result_dict:
            output = f"{self.database} -> "
            for table, no_of_rows in result_dict.items():
                output += f"{table}: {no_of_rows} rows | "
                if no_of_rows == 0:
                    self.report.update(msg="Table {} of server {} has 0 rows".format(
                            table, self.hostname))
            self.log_status(output)
        else:
            self.report.update(msg="Error for server {}".format(self.hostname))
