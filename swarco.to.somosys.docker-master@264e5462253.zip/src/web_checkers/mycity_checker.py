import requests
# from webbot import Browser
import logging
import jwt

from src.web_checkers import WebChecker

logger = logging.getLogger(__name__)


class MyCityChecker(WebChecker):
    def send_request(self):

        status, reason, access_token = self._get_access_token()
        if status is None:
            logger.error("Unable to get access token to MyCity")
            return self.return_response()
        if status != 200:
            return status, reason

        client = None
        try:
            client = requests.session()
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + access_token}

            user_id = jwt.decode(access_token, verify=False).get("sub", "")
            # Try to get list of devices
            response = client.get(self.url + '/api/swarco.core.um/users/{}'.format(user_id), headers=headers, timeout=60)
            logger.info("Checked: " + self.url + " , status: " + str(response.status_code))
            return self.return_response(response)
        except Exception as e:
            logger.error(f"Exception in send_request: {str(e)}")
            return self.return_response()
        finally:
            if client:
                client.close()

    def _get_access_token(self):
        client = None
        try:
            client = requests.session()
            payload = 'username={}&password={}&client_id=swarco.ui.base&grant_type=password'.format(self.auth[0],
                                                                                                    self.auth[1])
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}

            kc_url = "https://sso.swarco.com/auth/realms/swarco/protocol/openid-connect/token" if 'mycity.swarco.com' in\
                         self.url else self.url + "/auth/realms/swarco/protocol/openid-connect/token"
            # TODO: use refresh_token
            response = client.post(kc_url, headers=headers, data=payload, timeout=60)
            status_code, reason = self.return_response(response)
            if response.status_code == 200 and response.json():
                return status_code, reason, response.json().get("access_token")
            return status_code, reason, None
        except Exception as e:
            logger.error("Exception in get_access_token: {}".format(str(e)))
            return self.return_response()[0], self.return_response()[1], None
        finally:
            if client:
                client.close()

    # TODO: mimic browser login
    # def browser_login(self):
    #     web = Browser(showWindow=False)
    #     # web = Browser()
    #     web.go_to(self.url)
    #     web.type(self.auth[0], into='Email')
    #     web.type(self.auth[1], into='password')
    #     web.click('login')
    #     print(web.get_current_url())
    #     print(web.get_title())
    #     print(web.get_log_types())
    #     print(web.get_desired_capabilities())
    #     print(web.errors)
