from http.client import responses
import requests
import logging

from src.checker import Checker
from src.utils.common import get_last_report
from src.models.report import Report

logger = logging.getLogger(__name__)


class WebChecker:

    def __init__(self, url, auht, max_repeat=0):
        self.url = self.check_url(url)
        self.readable_url = url.replace("https://", "").split("/")[0]
        self.auth = self.check_auth(auht)
        self.max_repeat = max_repeat
        self.report = Report(msg="{} is reachable".format(self.readable_url), source=self.url)

    def check_auth(self, auth):
        if not isinstance(auth, tuple):
            raise TypeError("auth must be of type tuple")
        return auth

    def check_url(self, url):
        if not isinstance(url, str):
            raise TypeError("url must be of type url")
        if not url.startswith("https://"):
            raise ValueError("url must starts with https://")
        return url

    def send_request(self):
        client = None
        try:
            client = requests.session()
            resp = client.get(self.url, auth=self.auth, timeout=60)
            logger.debug("Checking: " + self.url + " , status: " + str(resp.status_code))
            return self.return_response(resp)
        except Exception as e:
            logger.error(f"Exception in send_request: {str(e)}")
            return self.return_response()
        finally:
            if client:
                client.close()

    @staticmethod
    def return_response(response=None):
        if response is None:
            return None, 'Something went wrong'

        if isinstance(response.reason, bytes):
            try:
                reason = response.reason.decode('utf-8')
            except UnicodeDecodeError:
                reason = response.reason.decode('iso-8859-1')
        else:
            reason = response.reason
        return response.status_code, (reason or responses[response.status_code])

    def is_server_error(self, status_code, reason):
        if status_code is None:
            logger.error("error for {}, reason: {}".format(self.readable_url, reason))
        elif 400 <= status_code < 500:
            logger.error(u'%s Client Error: %s for url: %s' % (status_code, reason, self.url))
        elif 500 <= status_code < 600:
            logger.error(u'%s Server Error: %s for url: %s' % (status_code, reason, self.url))
            return True

        return False

    def main_check(self):
        i = 0
        failed = False
        if self.max_repeat > 0:
            status_code = None
            reason = ''
            while i < self.max_repeat:
                status_code, reason = self.send_request()
                if status_code and status_code == 200:
                    failed = False
                    break
                else:
                    failed = True
                i += 1
            if failed:
                if self.is_server_error(status_code, reason):
                    self.update_and_save(status_code, reason)
                else:
                    self.save_border_up()
            else:
                self.save_border_up()

        else:
            status_code, reason = self.send_request()
            if self.is_server_error(status_code, reason):
                self.update_and_save(status_code, reason)
            else:
                self.save_border_up()
            if status_code and status_code == 200:
                self.save_border_up()

    def update_and_save(self, status_code, reason):
        self.report.update(status_code=status_code, reason=reason,
                           msg="{} is unreachable. Reason is: {}".format(self.readable_url, reason))
        Checker.reschedule_job(self.url)
        Report(status_code=status_code, reason=reason, source=self.url, value='down').save(
            force_insert=True)

    def save_border_up(self):
        last_report = get_last_report(source=self.url)
        if not last_report or last_report.value == 'down':
            Report(status_code=200, reason='ok', source=self.url, value='up').save(
                force_insert=True)

    def task(self):
        self.main_check()
