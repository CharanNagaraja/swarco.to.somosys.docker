import requests
import logging

from src.web_checkers import WebChecker

logger = logging.getLogger(__name__)


class BambooChecker(WebChecker):

    def send_request(self):
        client = None
        try:
            client = requests.session()
            # Retrieve the CSRF token first
            result = client.get(self.url, auth=self.auth, timeout=60)
            if result.status_code != 200:
                logger.error(f"Error in Bamboo request, status: {result.status_code}")
                return self.return_response(result)

            if 'atl.xsrf.token' in client.cookies:
                csrf_token = client.cookies['atl.xsrf.token']
            else:
                logger.error("Unable to get CSRF token: {}".format(self.url))
                return None, 'Unable to get xsrf token'

            login_data = dict(os_username=self.auth[0], os_password=self.auth[1], atl_token=csrf_token)
            resp = client.post(self.url, data=login_data, headers=dict(referer=self.url), timeout=60)
            logger.debug("Checking: " + self.url + " , status: "+str(resp.status_code))
            return self.return_response(resp)
        except Exception as e:
            logger.error(f"Exception in send_request: {str(e)}")
            return self.return_response()
        finally:
            if client:
                client.close()
