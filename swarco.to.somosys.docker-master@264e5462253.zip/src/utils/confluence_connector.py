import json
from datetime import datetime
from dateutil.relativedelta import relativedelta
import requests
import logging
from src.models.report import Report
from src.sla import Sla
from src.utils import ConfigHandler
from src.utils.common import response_to_json, num_to_month, truncate

logger = logging.getLogger(__name__)

# TODO: create inventory
URL_NAME = {
    "https://mycity.swarco.com": "MyCity platform",
    "https://bamboo.swarco.com/allPlans.action": "Bamboo",
    "https://git.swarco.com/projects": "Bitbucket",
    "https://confluence.swarco.com": "Confluence",
    "https://jira.swarco.com": "Jira"
}

# parent page_id refers to: https://confluence.swarco.com/display/TO/Software+Operating+Services
PARENT_CONF_PAGE = 76906964
CONF_PAGE_TITLE = "SLA reporting (Availabilities)"
CONF_PAGE_SPACE = "TO"


class ConfluenceConnector:
    data = {}

    @classmethod
    def create_data(cls, source):
        for date_, value in cls.data.items():
            sla, downtime = cls.calculate_sla(date_, source)
            cls.data.update({date_: (sla, downtime)})

    @classmethod
    def init_date(cls, from_):
        for m in range(1, 13):
            previous = from_ + relativedelta(months=-m)
            cls.data.update({previous: None})

    @classmethod
    def calculate_sla(cls, date_, source):

        if date_.year == 2019:
            return None, None
        # Assumption agreed with Rene
        if date_.year == 2020 and date_.month in [1, 2, 3, 4]:
            return 100, 0
        from_ = datetime(date_.year, date_.month, 1)
        to_ = date_ + relativedelta(months=+1)
        logger.info("calculating SLA source: {}, from {}, to: {}".format(source, from_, to_))
        res = Report.objects(source=source, created__gte=from_, created__lt=to_)

        # No event is recorded
        if not res:
            return 100, 0

        reference_period_in_minutes = (to_ - from_).total_seconds() / 60
        uptime_percent, downtime_seconds = Sla.main(response_to_json(res),
                                                    reference_period_in_minutes=reference_period_in_minutes)
        return uptime_percent, downtime_seconds

    @classmethod
    def generate_diagram(cls, source):
        t_header = ''
        t_col = ''
        n = 1
        from_ = datetime.now()
        logger.info("Generating diagram source: {}".format(source))
        cls.init_date(from_)
        cls.create_data(source)
        for date_, v in sorted(cls.data.items()):
            if not date_ or not v[0]:
                continue
            t_header += CONFLUENCE_TH.format(num_to_month(date_.month) + '-' + str(date_.year))
            t_col += CONFLUENCE_TD.format(truncate(v[0], 2))
            n += 1

        diagram = CONFLUENCE_DIAGRAM.format(subtitle=URL_NAME.get(source, ''), width=str(150*n), header=t_header, val=t_col)
        cls.data = {}
        return diagram

    @staticmethod
    def get_monitoring_page():
        client = None
        try:
            client = requests.session()
            resp = client.get(
                'https://confluence.swarco.com/rest/api/content/?title={}&spaceKey={}'.format(CONF_PAGE_TITLE,
                                                                                              CONF_PAGE_SPACE),
                auth=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                      ConfigHandler.get_value('toolchain', 'web', 'password')), timeout=60)
            if resp.status_code == 200:
                print(resp.json())
                if resp.json().get("results", []):
                    return resp.json().get("results")[0].get("id")
        except Exception as e:
            logger.error(str(e))
        finally:
            if client:
                client.close()

    @staticmethod
    def get_content_version(content_id):
        client = None
        try:
            client = requests.session()
            resp = client.get(
                'https://confluence.swarco.com/rest/api/content/{}?expand={}'.format(content_id, "version"),
                auth=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                      ConfigHandler.get_value('toolchain', 'web', 'password')), timeout=60)
            if resp.status_code == 200:
                print(resp.json())
                if resp.json().get("version", {}):
                    return resp.json().get("version").get("number")
        except Exception as e:
            logger.error(str(e))
        finally:
            if client:
                client.close()
        return None

    @classmethod
    def create_page_content(cls):
        diagrams = ''
        for url, name in URL_NAME.items():
            diagrams += "<p>" + cls.generate_diagram(source=url) + "</p>"
        return diagrams

    @classmethod
    def publish_diagrams(cls):
        monitoring_page_id = cls.get_monitoring_page()
        diagrams = cls.create_page_content()

        if monitoring_page_id:
            res = cls.update_page(monitoring_page_id, diagrams)
        else:
            res = cls.create_page(diagrams)
        return res

    @classmethod
    def update_page(cls, monitoring_page_id, diagrams):
        client = None
        try:
            client = requests.session()
            version_ = cls.get_content_version(monitoring_page_id)
            if not version_:
                return
            payload = {"id": monitoring_page_id,
                       "version": {"number": str(version_ + 1)},
                       "type": "page", "title": CONF_PAGE_TITLE,
                       "space": {"key": CONF_PAGE_SPACE},
                       "ancestors": [{"id": PARENT_CONF_PAGE}],
                       "body": {"storage": {
                           "value": """<p><h4>This page is automatically generated. Please do not edit.</h4></p>{}""".format(
                               diagrams), "representation": "storage"}}}
            resp = client.put('https://confluence.swarco.com/rest/api/content/{}'.format(monitoring_page_id),
                              auth=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                                    ConfigHandler.get_value('toolchain', 'web', 'password')),
                              timeout=60,
                              headers=({'Content-Type': 'application/json'}),
                              data=json.dumps(payload))
            if resp.ok:
                return True
        except Exception as e:
            logger.error(str(e))
        finally:
            if client:
                client.close()
        return False

    @classmethod
    def create_page(cls, diagrams):
        payload = {"type": "page", "title": CONF_PAGE_TITLE,
                   "space": {"key": CONF_PAGE_SPACE},
                   "ancestors": [{"id": PARENT_CONF_PAGE}],
                   "body": {"storage": {
                       "value": """<p><h4>This page is automatically generated. Please do not edit.</h4></p>{}""".format(
                           diagrams),
                       "representation": "storage"}}}
        client = None
        try:
            client = requests.session()
            resp = client.post('https://confluence.swarco.com/rest/api/content/',
                               auth=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                                     ConfigHandler.get_value('toolchain', 'web', 'password')),
                               timeout=60,
                               headers=({'Content-Type': 'application/json'}),
                               data=json.dumps(payload))
            if resp.ok:
                return True
        except Exception as e:
            logger.error(str(e))
        finally:
            if client:
                client.close()
        return False


CONFLUENCE_TH = '<th>{}</th>'
CONFLUENCE_TD = '<td>{}</td>'

CONFLUENCE_DIAGRAM = """<ac:structured-macro ac:name="chart" ac:schema-version="1">
                        <ac:parameter ac:name="type">bar</ac:parameter>
                        <ac:parameter ac:name="height">500</ac:parameter>
                        <ac:parameter ac:name="width">{width}</ac:parameter>
                        <ac:parameter ac:name="rangeAxisLowerBound">99.00</ac:parameter>
                        <ac:parameter ac:name="rangeAxisUpperBound">100</ac:parameter>
                        <ac:parameter ac:name="3D">true</ac:parameter>
                        <ac:parameter ac:name="subTitle">{subtitle}</ac:parameter>
                        <ac:parameter ac:name="legend">false</ac:parameter>
                        <ac:parameter ac:name="dataDisplay">after</ac:parameter>
                        <ac:parameter ac:name="xLabel">Rolling 12 months period</ac:parameter>
                        <ac:parameter ac:name="yLabel">Availability</ac:parameter>
                             <ac:rich-text-body>
                                 <table>
                                     <tbody>
                                         <tr>
                                             <th>Month-year</th>
                                             {header}
                                         </tr>
                                          <tr>
                                             <td>SLA %</td>
                                             {val}
                                          </tr>
                                     </tbody>
                                 </table>
                             </ac:rich-text-body>
                        </ac:structured-macro>"""


if __name__ == '__main__':
    ConfluenceConnector.publish_diagrams()
