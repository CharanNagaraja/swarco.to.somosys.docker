import argparse
import os
from cryptography.fernet import Fernet


CONFIG_ENV = os.getenv("CONFIG_ENV", "prod")

CONFIG_BASE_PATH = "../../config/{env}/{file_}"


def encrypt():
    parser = argparse.ArgumentParser(description='Encryption tool')
    parser.add_argument('-k', action="store", default=None, type=str, dest='key')

    results = parser.parse_args()
    if results.key:
        if os.path.exists(results.key):
            print("Using key: ", results.key)
            key = open(results.key, 'rb').read()
        else:
            raise FileNotFoundError("path: {} doesn't exist".format(results.key))
    else:
        print("Generating new key, path: {}".format(os.path.abspath("config/.config.key")))
        key = Fernet.generate_key()  # generate a key , will be used to descrypt
        with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), CONFIG_BASE_PATH.format(env=CONFIG_ENV, file_=".config.key")), 'wb') as f:
            f.write(key)
        os.chmod(os.path.join(os.path.abspath(os.path.dirname(__file__)), CONFIG_BASE_PATH.format(env=CONFIG_ENV, file_=".config.key")), 0o400)

    input_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), CONFIG_BASE_PATH.format(env=CONFIG_ENV, file_="config.yml"))  # path to file to encrypt 'config.yml'
    output_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), CONFIG_BASE_PATH.format(env=CONFIG_ENV, file_="config.yml.encrypted"))  # path to output file

    with open(input_file, 'rb') as f:
        data = f.read()

    fernet = Fernet(key)
    encrypted = fernet.encrypt(data)

    with open(output_file, 'wb') as f:
        f.write(encrypted)
    # Read only by owner file
    os.chmod(output_file, 0o400)


if __name__ == '__main__':
    encrypt()
