import os
import yaml
import logging

from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

CONFIG_ENV = os.getenv("CONFIG_ENV", "staging")

CONFIG_BASE_PATH = "../../config/{env}/{file_}"


def decrypt():
    # Check if the encrypted config exist otherwise fallback to plain text config
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), CONFIG_BASE_PATH.format(env=CONFIG_ENV, file_="config.yml.encrypted")))\
            and os.path.exists("/root/.config.key"):
        input_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), CONFIG_BASE_PATH.format(env=CONFIG_ENV, file_="config.yml.encrypted"))
        key = open("/root/.config.key", 'rb').read()
    else:
        input_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), CONFIG_BASE_PATH.format(env=CONFIG_ENV, file_="config.yml"))
        try:
            return open(input_file, "rb").read()
        except Exception as e:
            logger.error(f"Exception in decrypt: {str(e)}")
            raise e

    with open(input_file, 'rb') as f:
        data = f.read()

    fernet = Fernet(key)
    return fernet.decrypt(data)


class ConfigHandler:
    """Class that handles the configuration like loading from file, reading from it etc.
    """

    @classmethod
    def get_value(cls, *args):

        # get section
        section = args[0]

        # check if config file has section
        if section not in yaml.safe_load(decrypt()):
            logger.error(f"key {section} missing")
            raise KeyError

        # get values
        arg_list = list(args)  # convert tuple to list
        arg_list.pop(0)  # remove section from list

        # create lookup path
        parse_path = "yaml.safe_load(decrypt())['" + section + "']"

        for arg in arg_list:
            parse_path = parse_path + "['" + arg + "']"
        return eval(parse_path)
