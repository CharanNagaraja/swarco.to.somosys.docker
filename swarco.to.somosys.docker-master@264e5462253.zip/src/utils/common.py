import logging
from math import floor
from io import StringIO
import csv
from apscheduler.schedulers.background import BackgroundScheduler

from src.models.report import Report

logger = logging.getLogger(__name__)


def report_to_csv(data):
    output = StringIO()
    fields = ['_id', 'status_code', 'reason', 'created', 'value', 'source', 'v_']
    writer = csv.DictWriter(output, fieldnames=fields, delimiter=';')
    writer.writeheader()
    for row in data:
        writer.writerow(row.json_to_export())
    return output.getvalue()


def sla_to_csv(data):
    output = StringIO()
    fields = ['from', 'to', 'uptime_percent', 'reference_period_in_minutes', 'downtime_seconds']
    writer = csv.DictWriter(output, fieldnames=fields, delimiter=';')
    writer.writeheader()
    writer.writerow(data)
    return output.getvalue()


def response_to_json(data):
    res = []
    for row in data:
        res.append(row.json_to_export())
    return res


def get_last_report(source):
    return Report.objects(source=source).order_by('-id').first()


def schedule_confluence(job_function):
    sched = BackgroundScheduler(
        job_defaults={'misfire_grace_time': 15 * 60},
    )
    sched.start()

    sched.add_job(job_function, 'cron', day=1, hour=5, minute=00)


def num_to_month(month):
    d = {1: "January", 2: "February", 3: "March", 4: "April", 5: "May", 6: "June", 7: "July", 8: "August",
         9: "September", 10: "October", 11: "November", 12: "December"}

    return d.get(month, None)


def truncate(float_, n):
    return floor(float_ * 10 ** n) / 10 ** n
