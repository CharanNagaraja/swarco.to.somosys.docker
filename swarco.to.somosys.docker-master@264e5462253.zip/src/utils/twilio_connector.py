from twilio.rest import Client
from twilio.twiml.voice_response import VoiceResponse

from .config_handler import ConfigHandler

import logging

logger = logging.getLogger(__name__)
logging.getLogger("twilio").setLevel(logging.WARNING)
logging.getLogger("twilio.http_client").setLevel(logging.WARNING)


class TwilioConnector:
    """Class to use Twilio Python Helper Library for making calls"""

    client = Client(ConfigHandler.get_value('twilio', 'account', 'sid'),
                    ConfigHandler.get_value('twilio', 'account', 'auth_token'))

    @classmethod
    def make_call(cls, report):
        """
        Uses Twilio Python Helper Library and authenticated client attribute to make a call
        optionally sends a status callback to a specified URL
        :return: The unique string that identifies this call
        """
        if not isinstance(report, str):
            raise TypeError("report must be of type str")

        message = VoiceResponse()
        message.say(report)
        logger.info("OUTGOING CALL: " + str(message))
        voice_call = cls.client.calls.create(
            method='GET',
            twiml=str(message),
            to=ConfigHandler.get_value('twilio', 'call', 'to_phone_number'),
            from_=ConfigHandler.get_value('twilio', 'call', 'from_phone_number'),
            # status_callback_method='POST', TODO: could be used to check status of calls
            # status_callback=status_callback_url
        )
        return voice_call.sid
