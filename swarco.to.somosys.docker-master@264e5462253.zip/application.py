import datetime
import threading
import time

from flask import Flask, jsonify, request, Response
from flask_httpauth import HTTPTokenAuth

from src.checker import Checker, Job
from src.db_helper import initialize_db
from src.infra_checks.disk_checker import DiskChecker
from src.infra_checks.mysql_checker import MySQLChecker
from src.infra_checks.postgresql_checker import PostgreSQLChecker
from src.models.report import Report
from src.sla import Sla
from src.utils.common import report_to_csv, response_to_json, sla_to_csv, schedule_confluence
from src.utils.config_handler import ConfigHandler
from src.utils.confluence_connector import ConfluenceConnector
from src.utils.logger import setup_logging
from src.web_checkers import WebChecker, BambooChecker, MyCityChecker
import logging

logger = logging.getLogger(__name__)

setup_logging()

app = Flask(__name__)
checker = Checker
auth = HTTPTokenAuth(scheme='Bearer')

app.config['MONGODB_SETTINGS'] = {
    'host': 'mongodb://mongodb/reports',
    'username': ConfigHandler.get_value('app', 'mongo', 'db_username'),
    'password': ConfigHandler.get_value('app', 'mongo', 'db_password')
}
initialize_db(app)


@auth.verify_token
def verify_token(token):
    if token == ConfigHandler.get_value("app", "token"):
        return True
    return False


@app.route("/")
@auth.login_required
def ping():
    return "ping"


@app.route("/export", methods=['GET'])
@auth.login_required
def export():
    """
    Export events occured on the system for a given period
    format: format to be returned
    source: application url
    from: from date (INCLUSIVE)
    to: to date (EXCLUSIVE)
    :return: Response object
    """
    format_ = request.args.get('format', default='json', type=str)
    source = request.args.get('source', type=str)
    from_str = request.args.get('from', type=str)
    to_str = request.args.get('to', type=str, default=None)

    from_ = datetime.datetime.strptime(from_str, '%d-%m-%Y')
    to_ = datetime.datetime.strptime(to_str, '%d-%m-%Y') if to_str else datetime.datetime.utcnow()

    res = Report.objects(source=source, created__gte=from_, created__lt=to_)
    if format_.lower() == "json":
        return jsonify(res)

    return Response(
        report_to_csv(res),
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=reports.csv"})


@app.route("/sla", methods=['GET'])
@auth.login_required
def sla():
    """
    calculate SLA uptime in percent and number of downtime in seconds
    Loads params:
    format: format to be returned
    source: application url
    from: from date (INCLUSIVE)
    to: to date (Exclusive)
    :return: Response Object
    """
    format_ = request.args.get('format', default='json', type=str)
    source = request.args.get('source', type=str)
    from_str = request.args.get('from', type=str)
    to_str = request.args.get('to', type=str, default=None)

    from_ = datetime.datetime.strptime(from_str, '%d-%m-%Y')
    to_ = datetime.datetime.strptime(to_str, '%d-%m-%Y') if to_str else datetime.datetime.utcnow()

    res = Report.objects(source=source, created__gte=from_, created__lt=to_)

    reference_period_in_minutes = (to_ - from_).total_seconds() / 60
    if not res:
        uptime_percent = 100
        downtime_seconds = 0
    else:
        uptime_percent, downtime_seconds = Sla.main(response_to_json(res),
                                                    reference_period_in_minutes=reference_period_in_minutes)

    if not uptime_percent and not downtime_seconds:
        return jsonify({"response": "Unavailable, please verify your request parameters.."})

    response = {"from": from_, "to": to_, "uptime_percent": uptime_percent,
                "reference_period_in_minutes": reference_period_in_minutes, "downtime_seconds": downtime_seconds}
    if format_.lower() == 'json':
        return response

    return Response(
        sla_to_csv(response),
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=sla.csv"})


@app.route("/timeout", methods=['POST'])
@auth.login_required
def update_call_timeout():
    source = request.args.get('source', type=str)
    timeout = request.args.get('timeout', type=int)
    updated = checker.update_call_timeout(job_id=source, timeout=timeout)
    if updated:
        return jsonify({"response": "Timeout updated for {} after {} minutes.".format(source, timeout)})
    return jsonify({"response": "Error, please verify your request parameters."})


@app.route("/publish", methods=['POST'])
@auth.login_required
def publish():
    in_sec = request.args.get('in_sec', type=int, default=0)
    time.sleep(in_sec)
    result = ConfluenceConnector.publish_diagrams()
    if not result:
        return jsonify({"response": "An Error occured during publing diagrams"})
    return jsonify({"response": "Success, diagrams published to confluence"})


def create_jobs():
    global checker
    print("creating jobs")
    # checker.subscribe(
    #     Job(period_in_minutes=15,
    #         checker_obj=WebChecker("https://crowd.swarco.com", auht=(ConfigHandler.get_value('toolchain', 'web', 'email'),
    #                                                                  ConfigHandler.get_value('toolchain', 'web', 'password')),
    #                                max_repeat=3)))
    checker.subscribe(Job(15, BambooChecker("https://bamboo.swarco.com/allPlans.action",
                                            auht=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                                                  ConfigHandler.get_value('toolchain', 'web', 'password')),
                                            max_repeat=3)))
    checker.subscribe(Job(15, WebChecker("https://git.swarco.com/projects",
                                         auht=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                                               ConfigHandler.get_value('toolchain', 'web', 'password')),
                                         max_repeat=3)))
    # TODO: check network
    # checker.subscribe(Job(15, WebChecker("https://jirasd.swarco.com/servicedesk/customer/portals",
    #                                     auht=(ConfigHandler.get_value('toolchain', 'web', 'email'),
    #                                     ConfigHandler.get_value('toolchain', 'web', 'password')), max_repeat=3)))
    checker.subscribe(
        Job(3, MyCityChecker("https://mycity.swarco.com", auht=(ConfigHandler.get_value('CIP', 'web', 'username'),
                                                                ConfigHandler.get_value('CIP', 'web', 'password')),
                             max_repeat=3), reschedule_in_sec=15))
    checker.subscribe(
        Job(15, WebChecker("https://confluence.swarco.com", auht=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                                                                  ConfigHandler.get_value('toolchain', 'web',
                                                                                          'password')),
                           max_repeat=3)))
    checker.subscribe(
        Job(15, WebChecker("https://jira.swarco.com", auht=(ConfigHandler.get_value('toolchain', 'web', 'email'),
                                                            ConfigHandler.get_value('toolchain', 'web', 'password')),
                           max_repeat=3)))
    # checker.subscribe(
    #     Job(15,
    #         WebChecker("https://jirasd.swarco.com", auht=(ConfigHandler.get_value('toolchain', 'web', 'email'),
    #                                                       ConfigHandler.get_value('toolchain', 'web', 'password')), max_repeat=3)))

    # Bamboo Linux Build Agent
    # checker.subscribe(
    #     Job(60, DiskChecker(hostname=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_Linux_Build_Agent', 'IP'),
    #                         threshold=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_Linux_Build_Agent',
    #                                                           'threshold'),
    #                         username=ConfigHandler.get_value('toolchain', 'infra', 'ssh_username'),
    #                         cmd=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_Linux_Build_Agent', 'cmd'))))
    # NFS Share
    checker.subscribe(Job(60, DiskChecker(hostname=ConfigHandler.get_value('toolchain', 'infra', 'NFS_Share', 'IP'),
                                          threshold=ConfigHandler.get_value('toolchain', 'infra', 'NFS_Share',
                                                                            'threshold'),
                                          username=ConfigHandler.get_value('toolchain', 'infra', 'ssh_username'),
                                          cmd=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_Linux_Build_Agent',
                                                                      'cmd'))))

    # Bamboo PostgreSQL
    # checker.subscribe(
    #     Job(5, PostgreSQLChecker(hostname=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_PostgreSQL', 'IP'),
    #                              db_username=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_PostgreSQL',
    #                                                                  'db_username'),
    #                              tables_to_check=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_PostgreSQL',
    #                                                                      'tables_to_check'),
    #                              cmd=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_PostgreSQL', 'cmd'),
    #                              max_repeat=3,
    #                              database=ConfigHandler.get_value('toolchain', 'infra', 'Bamboo_PostgreSQL',
    #                                                               'database'),
    #                              parent_section_name="Bamboo_PostgreSQL")))
    # # Bitbucket PostgreSQL
    # checker.subscribe(
    #     Job(5, PostgreSQLChecker(hostname=ConfigHandler.get_value('toolchain', 'infra', 'BitBucket_PostgreSQL', 'IP'),
    #                              db_username=ConfigHandler.get_value('toolchain', 'infra', 'BitBucket_PostgreSQL',
    #                                                                  'db_username'),
    #                              tables_to_check=ConfigHandler.get_value('toolchain', 'infra', 'BitBucket_PostgreSQL',
    #                                                                      'tables_to_check'),
    #                              cmd=ConfigHandler.get_value('toolchain', 'infra', 'BitBucket_PostgreSQL', 'cmd'),
    #                              max_repeat=3,
    #                              database=ConfigHandler.get_value('toolchain', 'infra', 'BitBucket_PostgreSQL',
    #                                                               'database'),
    #                              parent_section_name="BitBucket_PostgreSQL")))
    #
    # # MySQL Master
    # checker.subscribe(
    #     Job(5,
    #         MySQLChecker(hostname=ConfigHandler.get_value('toolchain', 'infra', 'MySQL_master', 'IP'),
    #                      username=ConfigHandler.get_value('toolchain', 'infra', 'ssh_username'),
    #                      DBs_to_check=ConfigHandler.get_value('toolchain', 'infra', 'MySQL_master', 'DBs_to_check'),
    #                      cmd=ConfigHandler.get_value('toolchain', 'infra', 'MySQL_master', 'cmd'),
    #                      max_repeat=3,
    #                      parent_section_name="MySQL_master")))
    # TODO: check network
    # Jira SD MySQL
    # checker.subscribe(Job(5, MySQLChecker(use_sudo=True,
    #                                       username=ConfigHandler.get_value('toolchain', 'infra', 'Jira_SD_MySQL',
    #                                                                        'ssh_username'),
    #                                       password=ConfigHandler.get_value('toolchain', 'infra', 'Jira_SD_MySQL',
    #                                                                        'password'),
    #                                       hostname=ConfigHandler.get_value('toolchain', 'infra', 'Jira_SD_MySQL', 'IP'),
    #                                       DBs_to_check=ConfigHandler.get_value('toolchain', 'infra', 'Jira_SD_MySQL',
    #                                                                            'DBs_to_check'), max_repeat=3)))
    checker.run()


jobs = threading.Thread(target=create_jobs)
jobs.start()
reports = threading.Thread(target=checker.handle_report)
reports.start()

schedule_confluence(ConfluenceConnector.publish_diagrams)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=3000)
